package com.pay.config;



public class PayConfig {

//	partnerId = "111222333444555";
//			signKey = "99988888812121255544";
//			encKey = "111222333444555666777888";
//			merchantId = "99911010019";
//			notifyUrl = "http://pandans.mynetgear.com:7001/t_notify.htm
//	
	
	//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
 	public static String partner = "100000000000000";
 	public static String key = "h7jjcXPx7n2bmtK7L3mb";

 	

	// 调试用，创建TXT日志文件夹路径
	public static String log_path = "D:\\";

	// 字符编码格式utf-8
	public static String input_charset = "utf-8";
	
	// 签名方式 不需修改
	public static String sign_type = "MD5";

}
